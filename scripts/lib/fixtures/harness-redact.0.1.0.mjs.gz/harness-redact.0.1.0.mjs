// assets/scripts/harness-redact.mjs
//
// The one module EVERY hook this kit installs imports — lint-touched.mjs's
// PostToolUse sensor, verify-touched.mjs's Stop gate, and session-brief.mjs's
// SessionStart brief — and any future one must import this file rather than
// carry its own copy of anything in it. Two hooks each holding an
// independent copy of this logic is exactly the shape that lets a fix land
// in one and not the other; this project has already shipped four
// secret-exposure defects, and "the fix only ever reached one of the two
// copies" is a failure mode this extraction removes structurally, not by
// convention.
//
// THE NAME DESCRIBES ONE OF FIVE THINGS THIS MODULE NOW CARRIES. It is
// named for the first one it shared, stderr redaction, and the full list is:
//
//   1. REDACTION — `dropCommandFragments` (layer 1, a denylist of command
//      fragments) and `maskCredentials` (layer 2, a credential-shape
//      allowlist). The only part the name covers.
//   2. OUTPUT BOUNDS — `MAX_REPORT_LINES`, `MAX_REPORT_BYTES` and
//      `boundReport`, which keep a hook's output inside Claude Code's
//      10,000-character cap so it actually ARRIVES (see F3 below).
//   3. SESSION-MARKER STATE — `safeSessionId`, `markerPath`,
//      `readJSONMarker`/`writeJSONMarker`, `signatureOf`,
//      `MAX_BLOCKS_PER_SESSION`: the per-session bookkeeping both process
//      hooks bound themselves with.
//   4. THE PROJECT ROOT — `projectRoot`, the one answer all three hooks
//      use (whole-branch review, F4: there were two).
//   5. THE HANDOFF LOCATION — `HANDOFF_CANDIDATES` and `findHandoff`,
//      shared with `scripts/lib/detect-harness.mjs` so detection and the
//      hook cannot disagree about where the file is (F4 again).
//
// Coordinator ruling (post-review, concern 3): the name is KEPT, and the
// mismatch is disclosed here rather than left for the next reader to
// discover. Renaming is not available: `REDACT_PATH`
// (`.claude/scripts/harness-redact.mjs`) is recorded in every manifest this
// tool has ever written, and `uninstall` reads that manifest to decide what
// it may remove — so a rename orphans every existing install's record of
// this file, permanently, with no notice. A name that under-describes its
// module is survivable; one that under-describes it SILENTLY sends the next
// reader looking in the wrong file for `findHandoff` or `boundReport`.
// If this is ever renamed, the manifest needs a migration first, not a
// `git mv`.
//
// Whole-branch review, F3: session-brief.mjs is the reason the bound below
// has a byte limit at all — `MAX_REPORT_LINES`' own comment cited it as the
// model — and it was the one hook that never got that byte limit, because
// it predates this module and could not import it. It imports it now.
//
// Two independent layers:
//
//   Layer 1 (dropCommandFragments): a denylist against what is KNOWN to
//   have come from a command the calling hook itself built. A shell or
//   interpreter can echo a FRAGMENT of a failing command line, not
//   necessarily the whole string (confirmed: node's own SyntaxError
//   reporter prints only the text after an unbalanced quote) — so every
//   whitespace-delimited token of length >= 8 drawn from the command(s) is
//   treated as sensitive, and any surviving line containing one is dropped
//   outright. `exemptions` carries whatever legitimately belongs in a real
//   diagnostic and must never be treated as a redactable fragment: what
//   the caller appended to its own command (the edited file), and — via
//   `pathTokenExemptions` — the command's own path and config-file tokens
//   (`eslint src/components`, `tsc -p tsconfig.build.json`), which every
//   diagnostic names and which are not secrets.
//
//   Layer 2 (maskCredentials): a credential-SHAPE allowlist, independent of
//   layer 1 — catches a credential-shaped value arriving from ANYWHERE in
//   the output, including content the hook never built itself (e.g. a
//   linted file's own source, or a verification command's own diagnostic
//   text). Masks the VALUE and never drops the line: a genuine diagnostic
//   that happens to mention a credential should still reach Claude, with
//   the secret starred out, not disappear entirely.
//
// Attribution — deciding what the output is even ABOUT — is each caller's
// own concern and stays in the caller; it has nothing to do with redaction
// and does not belong in a shared chokepoint.
import { spawn, spawnSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { constants, existsSync, lstatSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { tmpdir, userInfo } from 'node:os';
import { join, resolve } from 'node:path';

/**
 * Whitespace-delimited tokens of length >= 8 drawn from `command`, in
 * first-seen order, minus anything in `exemptions`.
 */
export function commandTokens(command, exemptions = new Set()) {
  const seen = new Set();
  const tokens = [];
  for (const raw of command.split(/\s+/)) {
    const t = raw.replace(/^['"]+|['"]+$/g, '');
    if (t.length < 8 || exemptions.has(t) || seen.has(t)) continue;
    seen.add(t);
    tokens.push(t);
  }
  return tokens;
}

// A command token that names a config file: a config-shaped extension, or a
// dotted `*rc` name (`.eslintrc`, `.eslintrc.cjs`), standing alone or attached
// to a flag (`--config=eslint.config.js`). Anchored at the end of the token so
// a value that merely ENDS in one of these characters sequences after a
// credential flag is still excluded by the flag check in
// `pathTokenExemptions`.
const CONFIG_SHAPED = /(?:\.(?:json|ya?ml|toml|[cm]?[jt]s|cfg|ini|conf)|(?:^|[/=])\.[\w-]+rc(?:\.\w+)?)$/i;
// A flag whose NAME is credential-shaped is never exempt, whatever its value
// looks like: `--token=secrets.json` is still a token.
const CREDENTIAL_FLAG = /^--?(?:[\w-]*(?:token|key|secret|password|passwd|pwd|auth)[\w-]*)=/i;
// Nor is anything that can carry userinfo: a URL or an `scp`-style
// `user@host:path`, whatever it ends in (final review: `…@host/x.json`
// was exempt by its suffix and a credential URL survived layer 1).
const CARRIES_USERINFO = /:\/\/|@/;

/**
 * The tokens of `command` that name a PATH or a CONFIG FILE rather than
 * anything secret, for use as layer-1 exemptions. Audit Tier 1, finding 2
 * (docs/2026-11-02-audit-findings.md): with `eslint src/components`,
 * `ruff check backend/app` or `eslint -c .eslintrc.cjs .`, every diagnostic
 * named the path or config the command named, so `dropCommandFragments`
 * treated every diagnostic as an echo of the command and the hook reported
 * nothing — the sensor's one job, failing silently.
 *
 * Exempt: (a) a token that is a DIRECTORY prefix of one of `paths` (whole
 * segments — `src/comp` is not a prefix of `src/components/x`), with a
 * leading `./` or trailing `/` tolerated, or the path itself; (b) a token
 * shaped like a config file (`CONFIG_SHAPED`). Never exempt: a token whose
 * flag name is credential-shaped (`CREDENTIAL_FLAG`). Only tokens `commandTokens`
 * would produce are returned, so the result composes with it directly.
 */
export function pathTokenExemptions(command, paths = []) {
  const normalized = paths.map(p => p.replace(/^\.\//, '').replace(/\/+$/, ''));
  const isDirPrefixOrSelf = token => {
    const t = token.replace(/^\.\//, '').replace(/\/+$/, '');
    return t.length > 0 && normalized.some(p => p === t || p.startsWith(t + '/'));
  };
  const exempt = new Set();
  for (const token of commandTokens(command)) {
    if (CREDENTIAL_FLAG.test(token) || CARRIES_USERINFO.test(token)) continue;
    if (isDirPrefixOrSelf(token) || CONFIG_SHAPED.test(token)) exempt.add(token);
  }
  return exempt;
}

/**
 * Layer 1. `commands` is every raw command string the calling hook itself
 * built (e.g. `[lintScript, fullCommand]`, or a single verify command) —
 * each is checked both as a whole-string match (the "shell echoes the
 * entire line" case) and tokenized for the fragment case.
 */
export function dropCommandFragments(lines, commands, exemptions = new Set()) {
  const tokens = [...new Set(commands.flatMap(c => commandTokens(c, exemptions)))];
  return lines.filter(l => {
    if (commands.some(c => l.includes(c))) return false;
    return !tokens.some(t => l.includes(t));
  });
}

/**
 * Layer 2. Credential-shaped values, independent of where they came from.
 * Ruff and biome print source snippets, so a secret in a linted file reaches
 * this mask whether or not the command mentioned it; the list therefore
 * tracks the shapes the sweep (scripts/lib/detect-exposure.mjs) knows, plus
 * what only ever appears in OUTPUT: a JWT, a URL's userinfo, a Basic header,
 * a `key: value` line in any of its spellings, and a PEM block (audit Tier
 * 3, finding 24). Order matters only where rules overlap: the key-value rule
 * runs last so a vendor token after `api_key:` is already starred by then.
 * Masking keeps the line and the key; only the value is replaced.
 */
export const CREDENTIAL_RULES = [
  // Floors sit a little BELOW the sweep's (detect-exposure.mjs): a mask that
  // stars a shorter string than the sweep would flag is the safe direction,
  // while a blanket {6,} masked ordinary identifiers such as npm_config_cache,
  // hf_transfer and ghp_client out of real diagnostics (Tier 3 review,
  // Minor 4). Ten characters of body is where the identifiers stop and the
  // tokens begin.
  [/\bsk-[A-Za-z0-9_-]{10,}/g, '***'],
  [/\b(?:sk|pk|rk)_(?:live|test)_[A-Za-z0-9]{10,}/g, '***'],
  [/\bglpat-[A-Za-z0-9_-]{10,}/g, '***'],
  [/\bglrt-[A-Za-z0-9_-]{10,}/g, '***'],
  [/\bgh[opsur]_[A-Za-z0-9]{10,}/g, '***'],
  [/\bgithub_pat_[A-Za-z0-9_]{10,}/g, '***'],
  [/\bnpm_[A-Za-z0-9]{36}\b/g, '***'],
  [/\bAKIA[A-Za-z0-9]{12,}/g, '***'],
  [/\bAIza[0-9A-Za-z_-]{35}\b/g, '***'],
  [/\bxox[abprs]-[A-Za-z0-9-]{10,}/g, '***'],
  [/\bxapp-[A-Za-z0-9-]{10,}/g, '***'],
  [/\bhf_[A-Za-z0-9]{12,}/g, '***'],
  [/\bdckr_pat_[A-Za-z0-9_-]{10,}/g, '***'],
  [/\bpypi-[A-Za-z0-9_-]{10,}/g, '***'],
  // A JWT: three base64url segments, the first always `eyJ` (`{"`).
  [/\beyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}/g, '***'],
  // Userinfo in a URL: `scheme://user:secret@host` — the user name (which
  // may be empty, as in `redis://:secret@host`) is kept, the secret is not.
  // A URL with no password is left alone.
  [/(:\/\/[^/\s:@]*:)[^@\s/]+@/g, '$1***@'],
  [/\bBearer\s+\S+/gi, 'Bearer ***'],
  [/\bBasic\s+[A-Za-z0-9+/=]{12,}/g, 'Basic ***'],
  // A PEM block, on one line or across several (lines are masked one at a
  // time by the hooks, so the single-line form is what usually arrives).
  [/-----BEGIN [A-Z ]*PRIVATE KEY-----[\s\S]*?-----END [A-Z ]*PRIVATE KEY-----/g, '***'],
  [/-----BEGIN [A-Z ]*PRIVATE KEY-----.*/g, '***'],
  [/(--(?:token|auth-token|api-key)=)\S+/gi, '$1***'],
  // `password=x`, `password: x`, `"password": "x"`, `api_key: x` … — the
  // same key list the sweep uses, in any quoting, `=` or `:`.
  [/((?:["']?)(?:password|passwd|pwd|api[_-]?key|client[_-]?secret|secret[_-]?key|access[_-]?token|auth[_-]?token)(?:["']?)\s*[:=]\s*)["']?[^\s"',;]+["']?/gi, '$1***'],
];

export function maskCredentials(line) {
  let masked = line;
  for (const [re, replacement] of CREDENTIAL_RULES) masked = masked.replace(re, replacement);
  return masked;
}

// --- Bounding what reaches stderr -----------------------------------------
//
// Shared so neither hook's bound can silently drift out of sync with the
// other's — see MAX_REPORT_LINES/MAX_REPORT_BYTES below.

/** The line bound every hook's output shares, session-brief.mjs included —
 * it used to carry its own copy of this number and nothing else. */
export const MAX_REPORT_LINES = 60;
/**
 * A line-count bound alone cannot stop a single very long line (minified
 * output, a one-line stack trace, a JSON formatter run with no pretty-print)
 * from pushing megabytes into Claude's context at the default 10 MB spawn
 * buffer — measured: a single 50 000-character line reached stderr in full
 * before this existed. 10 000 bytes is generous for a genuine diagnostic
 * and far below anything that would flood a turn.
 *
 * It is also EXACTLY Claude Code's own documented cap, which is the reason
 * the number matters rather than merely being generous. From the hooks
 * reference: a hook's `additionalContext`, `systemMessage` and
 * `initialUserMessage` strings, and its plain stdout, are capped at 10,000
 * characters; over the limit, Claude Code saves the output to a file in the
 * session directory and replaces it with the file path plus a preview of the
 * first 2,000 characters — and "Claude Code doesn't ask Claude to read the
 * file". So exceeding this is not a flooded context, it is the output
 * SILENTLY NOT ARRIVING. That is what F3 cost session-brief.mjs: past the
 * cap, the handoff was replaced by a path Claude is never told to open, and
 * nothing anywhere reported it.
 */
export const MAX_REPORT_BYTES = 10_000;

/**
 * Cuts `str` to at most `maxBytes` UTF-8 bytes, never mid-character: `end`
 * is the first byte NOT kept, so while it is a UTF-8 continuation byte
 * (`10xxxxxx`) the character before it is being split and the cut walks
 * back. Without this, a multi-byte character straddling the boundary decodes
 * to U+FFFD — a corrupted last character in the one place a user is reading
 * for information.
 */
function sliceUtf8(str, maxBytes) {
  const buf = Buffer.from(str, 'utf8');
  if (buf.length <= maxBytes) return str;
  let end = maxBytes;
  while (end > 0 && (buf[end] & 0xc0) === 0x80) end--;
  return buf.subarray(0, end).toString('utf8');
}

/**
 * Bounds `lines` first by count, then by total byte size, and returns the
 * final string to write (without a trailing newline). `header` is
 * prepended before either bound is computed, since it counts toward the
 * byte budget too. No hook may write to its output stream through any path
 * but this one plus its own single `write` call site — see each hook's own
 * comment on its chokepoint.
 *
 * Whole-branch review, F3: the byte bound used to cut at exactly
 * `MAX_REPORT_BYTES` and THEN append the truncation notice, so the string
 * this returned was ~10,050 bytes — over Claude Code's 10,000-character cap
 * by the length of its own notice, which is precisely the cap this constant
 * exists to stay under. Two things are fixed here, because a bound that is
 * fifty bytes over is not a bound at all for the failure mode it exists to
 * prevent:
 *
 *   - the notice is now INSIDE the budget, not appended after it; and
 *   - one further byte is reserved for the single trailing newline every
 *     caller adds (all three hooks write `boundReport(...) + '\n'`), so the
 *     bound holds on what is actually WRITTEN rather than on an
 *     intermediate string nothing emits.
 *
 * Contract, therefore: this returns at most `MAX_REPORT_BYTES - 1` bytes,
 * and `boundReport(...) + '\n'` is at most `MAX_REPORT_BYTES`.
 */
export function boundReport(lines, header = '') {
  const shown = lines.slice(0, MAX_REPORT_LINES);
  let report = header + shown.join('\n');
  if (lines.length > MAX_REPORT_LINES) {
    report += `\n--- truncated: ${lines.length - MAX_REPORT_LINES} more line(s) ---`;
  }
  const budget = MAX_REPORT_BYTES - 1; // the caller's trailing newline
  if (Buffer.byteLength(report, 'utf8') > budget) {
    const notice = '\n--- truncated: output exceeded the byte limit ---';
    report = sliceUtf8(report, budget - Buffer.byteLength(notice, 'utf8')) + notice;
  }
  return report;
}

// --- The two facts every hook needs before it can do anything -------------

/**
 * The repository root, as Claude Code reports it, falling back to the
 * process's own working directory.
 *
 * Whole-branch review, F4, secondary: three hooks, two conventions. This is
 * what lint-touched.mjs and verify-touched.mjs both already did inline;
 * session-brief.mjs used a bare `process.cwd()` and DOCUMENTED the
 * assumption ("Assumes cwd is the repository root at SessionStart") rather
 * than removing it — so any SessionStart invocation whose cwd was not the
 * project root printed "no HANDOFF.md in this repository yet" into the
 * model's context, as a false premise, at the start of every session. One
 * function, three callers.
 */
export function projectRoot() {
  return process.env.CLAUDE_PROJECT_DIR || process.cwd();
}

/**
 * The two conventional locations for a repository's handoff file, in
 * precedence order, and the one function that resolves them.
 *
 * Whole-branch review, F4. `detect-harness.mjs` credited `P4.handoff` from
 * `existsAny(root, ['HANDOFF.md', 'docs/HANDOFF.md'])` while the hook it
 * installs read `join(process.cwd(), 'HANDOFF.md')` and nothing else — so a
 * repository whose handoff lives at `docs/HANDOFF.md` was credited
 * `declared` by `detect` and then told, by the artefact that same run
 * installed three lines later, that it had no handoff file at all. Printed
 * into the model's context, not a terminal: a false premise the agent starts
 * from, about a file this very tool had already proved exists.
 *
 * The direction chosen is THE HOOK LOOKS WHERE DETECTION CREDITED, not the
 * reverse, for two reasons. First, `docs/HANDOFF.md` is a real convention —
 * this list is the tool's own admission that repositories put it there — and
 * narrowing detection to the root would make `P4.handoff` propose CREATING a
 * root `HANDOFF.md` in a repository that already has one under `docs/`,
 * which turns a false sentence into a duplicate file and leaves the user
 * with two handoffs that disagree. A wrong write is worse than a wrong read.
 * Second, widening the hook costs one extra `existsSync`.
 *
 * `detect-harness.mjs` imports THIS function rather than keeping its own
 * list, so the two sides cannot drift again. That is the only way they can
 * be shared: the hook is a file copied verbatim into a user's repository,
 * where the only module beside it is this one, so a constant in
 * `scripts/lib/` could never reach it. The dependency runs the other way,
 * at build time, and the installed copy depends on nothing new.
 */
export const HANDOFF_CANDIDATES = ['HANDOFF.md', 'docs/HANDOFF.md'];

export function findHandoff(root) {
  for (const rel of HANDOFF_CANDIDATES) {
    if (existsSync(join(root, rel))) return rel;
  }
  return null;
}

// --- The rules registry: location and parser -----------------------------
//
// Phase 3 (intent and rules — see docs/superpowers/specs/2026-11-02-intent-
// and-rules-design.md). `docs/harness/RULES.md` is where a repository
// records its own rules, each with the mechanism that ENFORCES it, so a rule
// Claude is merely told (`enforced-by: none`) can be told apart from one it
// cannot break (a deny rule, a hook, a lint, a test, a critic).
//
// The parser lives HERE, in the shared hook asset, for exactly the reason
// `findHandoff` does: two things must agree on what a rule is — `detect`
// (scripts/lib/rules-evidence.mjs, which credits `P3.rules`) and the
// installed `rules-brief.mjs` hook (which re-injects the rules into every
// prompt). The hook is copied verbatim into a user's `.claude/scripts/`,
// where the only module beside it is this one, so a parser in
// `scripts/lib/` could never reach it. Same import direction, same reason,
// same cost (none at runtime: node builtins only).
//
// Why Markdown with `key: value` bullets and not JSON or YAML: this file is
// written and edited by a HUMAN — the kit scaffolds the shape and never
// writes a rule — so it must stay pleasant to edit by hand, and the kit has
// no YAML parser (zero dependencies). A 40-line parser is the cheaper
// choice. Anthropic's observation that models alter JSON less than Markdown
// applies to machine-maintained state; this is not that.
//
// HTML comments are stripped FIRST. That is what makes the shipped
// template's worked example inert: everything the kit itself puts in the
// scaffold sits inside one comment, so a user who never edits the file has
// a registry of zero rules, never a registry of our example pretending to
// be theirs. (`markdownRemainder` in uninstall-lib.mjs relies on the same
// property from the other side, to recognise an unfilled scaffold.)

export const RULES_PATH = 'docs/harness/RULES.md';

/** Every value `enforced-by` may take. `none` is a claim, not an enforcer —
 * it is recorded so the registry can say plainly which rules are told and
 * which are held, and `review` means a human reviewer is the mechanism. */
export const ENFORCERS = Object.freeze(['deny', 'hook', 'lint', 'test', 'critic', 'ci', 'review', 'none']);

export function findRules(root) {
  return existsSync(join(root, RULES_PATH)) ? RULES_PATH : null;
}

// `## <id> — <rule>`: the id is one token (letters, digits, `_`, `.`, `-`,
// starting with a letter); the separator is an em-dash, en-dash or hyphen
// run, or just whitespace; the rule is whatever follows, trimmed.
const RULE_HEADING = /^##\s+([A-Za-z][\w.-]*)(?:\s+[—–-]+\s+|\s+)(\S.*)$/;
const ANY_H2 = /^##(\s|$)/;
const KEY_LINE = /^\s*[-*]\s*([A-Za-z][\w-]*)\s*:\s*(.*)$/;

/** Canonical field for a key as a user might spell it: `enforced-by`,
 * `enforcedBy`, `enforced_by`, `Enforced-By` all mean `enforcedBy`. */
function fieldFor(key) {
  const k = key.toLowerCase().replace(/[-_]/g, '');
  if (k === 'enforcedby') return 'enforcedBy';
  if (k === 'lastverified') return 'lastVerified';
  if (k === 'why' || k === 'pointer' || k === 'verify' || k === 'priority' || k === 'status') return k;
  return null; // unknown keys are ignored, as Claude Code ignores unknown frontmatter
}

/**
 * Parses the registry text. Never throws; `null`/non-string input is an
 * empty registry. Returns `{ rules, problems }` where every problem is a
 * one-line human sentence naming the rule id or the line number — never a
 * rule's own text, since a rule line may carry anything and this output
 * reaches `docs/harness/detect.json`, which is committed. The one value
 * echoed is a rejected `enforced-by` token, because naming what was
 * rejected is the only way the sentence can be acted on.
 *
 * Each rule: `{ id, rule, why, enforcedBy, pointer, verify, priority, status,
 * lastVerified, line }`. `status` is `active` (default) or `superseded` — a
 * superseded rule stays in the file as a record but is excluded from
 * re-injection and from the enforcement counts; `lastVerified` is a
 * YYYY-MM-DD string or null (anything else is reported, never guessed at).
 * `enforcedBy` is always one of ENFORCERS (an absent or unknown value is
 * recorded as `none` AND reported, so a typo cannot silently promote a
 * claim to an enforcer); `priority` is `high` or `normal`; `line` is the
 * 1-based line of the heading in the ORIGINAL text (comments are blanked,
 * not removed, so line numbers survive the strip).
 */
export function parseRules(text) {
  if (typeof text !== 'string' || text.length === 0) return { rules: [], problems: [] };
  // Blank out comments but keep their newlines, so `line` stays honest.
  const stripped = text.replace(/<!--[\s\S]*?-->/g, m => m.replace(/[^\n]/g, ''));
  const lines = stripped.split(/\r?\n/);
  const rules = [];
  const problems = [];
  const seen = new Set();
  let current = null;
  const close = () => {
    if (!current) return;
    if (current.enforcedBy === undefined) {
      problems.push(`${current.id}: no enforced-by line — recorded as none`);
      current.enforcedBy = 'none';
    }
    rules.push(current);
    current = null;
  };
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    if (ANY_H2.test(line)) {
      close();
      const m = line.match(RULE_HEADING);
      if (!m) {
        problems.push(`line ${i + 1}: heading is not "<id> — <rule>"`);
        continue;
      }
      const id = m[1];
      if (seen.has(id)) {
        problems.push(`duplicate id ${id} at line ${i + 1} — the first definition is kept`);
        continue;
      }
      seen.add(id);
      current = { id, rule: m[2].trim(), why: null, enforcedBy: undefined, pointer: null, verify: null, priority: 'normal', status: 'active', lastVerified: null, line: i + 1 };
      continue;
    }
    if (!current) continue;
    const k = line.match(KEY_LINE);
    if (!k) continue;
    const field = fieldFor(k[1]);
    if (!field) continue;
    const value = k[2].trim();
    if (field === 'enforcedBy') {
      const v = value.toLowerCase();
      if (ENFORCERS.includes(v)) current.enforcedBy = v;
      else { problems.push(`${current.id}: enforced-by "${v}" is not one of ${ENFORCERS.join('/')} — recorded as none`); current.enforcedBy = 'none'; }
    } else if (field === 'priority') {
      current.priority = value.toLowerCase() === 'high' ? 'high' : 'normal';
    } else if (field === 'status') {
      const v = value.toLowerCase();
      if (v === 'active' || v === 'superseded') current.status = v;
      else problems.push(`${current.id}: status "${v}" is not active or superseded — recorded as active`);
    } else if (field === 'lastVerified') {
      if (/^\d{4}-\d{2}-\d{2}$/.test(value)) current.lastVerified = value;
      else problems.push(`${current.id}: last-verified is not a YYYY-MM-DD date — recorded as unknown`);
    } else {
      current[field] = value.length ? value : null;
    }
  }
  close();
  return { rules, problems };
}

// --- Session-scoped marker state, shared by both hooks' own bounding -----
//
// Both lint-touched.mjs (dedupe a standing lint error per file) and
// verify-touched.mjs (dedupe a standing verification failure, bound how
// many times either ever blocks/reports per session) need the identical
// building blocks: a sanitized session_id, a safe-to-write location under
// the OS temp directory, and a read/write pair that never throws. One copy
// here instead of two, for the same reason the redaction layers are one
// copy instead of two.

/**
 * `session_id` is attacker-shaped: it comes straight off a hook payload and
 * would otherwise go straight into a filesystem path. A `../`-laden or
 * absolute value could escape the marker directory entirely; a NUL byte
 * would make any `fs` call on the resulting path throw outright. Reducing
 * to a strict allowlisted charset and refusing anything else outright means
 * there is no path left for a malicious value to take — a value that does
 * not survive this check is never used to build a path at all. The caller
 * must treat `null` as "skip tracking for this invocation", never invent a
 * fallback filename.
 */
const SAFE_SESSION_ID = /^[A-Za-z0-9_-]+$/;

export function safeSessionId(sessionId) {
  return typeof sessionId === 'string' && sessionId.length > 0 && sessionId.length <= 200 && SAFE_SESSION_ID.test(sessionId)
    ? sessionId
    : null;
}

/**
 * A stable, filesystem-safe tag for the current OS user. Hashed (not used
 * raw) so an unusual username can never itself become a path-safety
 * concern the way `session_id` already is one. Falls back to a constant
 * rather than throwing — `os.userInfo()` can throw in a minimal/sandboxed
 * environment with no resolvable home directory — which only widens the
 * shared-temp-directory exposure Finding 10 already documents as an
 * accepted residual risk, never a crash.
 */
function userTag() {
  try {
    const id = typeof process.getuid === 'function' ? String(process.getuid()) : userInfo().username;
    return createHash('sha256').update(id, 'utf8').digest('hex').slice(0, 16);
  } catch {
    return 'unknown';
  }
}

/** A stable, filesystem-safe tag for a repository root, so two different
 * repositories (or a repository moved/renamed) never share a marker even
 * if a `session_id` were ever reused across them. */
export function rootTag(root) {
  return createHash('sha256').update(resolve(root), 'utf8').digest('hex').slice(0, 16);
}

/**
 * The directory every marker lives under: per-user (see userTag), under
 * the OS temp directory, created with owner-only permissions on POSIX
 * (`0o700` — a no-op on win32, where ACLs already default to per-user
 * access under `%TEMP%`). This narrows, but does not eliminate, the
 * pre-seeded-marker exposure a shared temp directory allows across
 * DIFFERENT users; within the same user and the same machine the residual
 * risk is accepted and documented (Finding 10) rather than chased further.
 * Creation failure is swallowed — the caller's own marker read/write is
 * already failure-tolerant, and a directory that cannot be created simply
 * means every marker operation beneath it will consistently fail-safe too.
 *
 * `HK_MARKER_DIR` overrides the location, following the same `HK_*`
 * convention as `HK_LINT_TIMEOUT_MS` and friends. It exists for one reason:
 * this is ONE FIXED DIRECTORY shared by every invocation of every hook, for
 * the life of the machine, and nothing removes what is written there.
 * Markers are keyed by `(rootTag, namespace, sessionId)`, so they never
 * COLLIDE — but they do accumulate, one file per repository per namespace
 * per session, for ever.
 *
 * BOUNDED, THEN ACCEPTED, AND WRITTEN DOWN HERE RATHER THAN LEFT TO BE
 * DISCOVERED. Two separate decisions:
 *
 *   BOUNDED — `markerPath` shards by `rootTag` as a DIRECTORY level, so the
 *   entry count in any one directory grows with sessions PER REPOSITORY
 *   rather than with sessions globally. Measured before that change, from
 *   this project's own test runs alone: 8983 entries in the one shared
 *   directory. That is also where the naming scheme's own history is
 *   visible — flat, pre-subdirectory markers from earlier iterations are
 *   still sitting there, including one written for an EMPTY session id,
 *   which is the plainest possible proof that markers outlive the code that
 *   wrote them.
 *
 *   ACCEPTED — the remaining accumulation is NOT fixed with a cleanup sweep.
 *   A marker is a few dozen bytes of JSON and the OS cleans its temp
 *   directory; deleting files is a destructive action on the hot path of a
 *   hook that fires on every edit and every turn end, and the one thing
 *   worse than litter is a hook that removes the wrong file while a turn is
 *   in flight. Litter in a temp directory is the better trade, and it is the
 *   trade this comment records.
 *
 * Stale markers from an older naming scheme are never read by the current
 * one and are harmless: a marker's absence is the permissive default
 * everywhere (see `readJSONMarker`'s `fallback`), so an unreachable marker
 * can only ever cost a hook one un-deduplicated report.
 *
 * In TESTS the accumulation is removed outright, which is what the override
 * is for: `scripts/lib/test-marker-sandbox.mjs` points this at a per-run
 * temp directory and deletes it in a teardown that runs on pass, fail or
 * throw. Measured before that existed: 8983 files in the shared directory on
 * the development machine, which is a credible mechanism for a rare,
 * unattributable failure in a suite that sets sub-second timeouts.
 */
/**
 * True when `dir` is a real directory of ours: not a link (a symlink or
 * junction planted at a predictable path redirects every marker read and
 * write — audit Tier 4, finding 26), and on POSIX not another user's. A
 * refusal means "no marker directory": `markerPath` returns null and every
 * caller's existing fail-open path takes over.
 */
function ownDirectory(dir) {
  let st;
  try {
    st = lstatSync(dir);
  } catch {
    return false;
  }
  if (st.isSymbolicLink() || !st.isDirectory()) return false;
  if (typeof process.getuid === 'function' && st.uid !== process.getuid()) return false;
  return true;
}

/** Creates `dir` if absent and returns it, or null when it is not ours. */
function ensureOwnDirectory(dir) {
  try {
    mkdirSync(dir, { recursive: true, mode: 0o700 });
  } catch {
    // best-effort — see comment above; ownDirectory decides from what is there
  }
  return ownDirectory(dir) ? dir : null;
}

export function markerDir() {
  const override = process.env.HK_MARKER_DIR;
  const dir = override && override.length > 0
    ? override
    : join(tmpdir(), `kh-harness-stop-${userTag()}`);
  return ensureOwnDirectory(dir);
}

/**
 * Builds a marker's full path: the per-user directory, then a DIRECTORY
 * named for the repo-root tag, then `<namespace>-<sanitized session_id>` as
 * the filename — so neither a cross-repo nor a cross-session collision is
 * possible, AND two DIFFERENT hooks sharing a (root, session_id) pair never
 * read or write each other's marker. lint-touched.mjs and verify-touched.mjs
 * track differently-shaped state (per-file signatures vs. a single
 * count/lastSignature/timedOut) under the SAME root and session; without
 * `namespace` they would silently corrupt one another's bookkeeping the
 * moment both fired in the same session.
 *
 * `rootTag` is a DIRECTORY LEVEL rather than a filename prefix, and that is
 * the only thing that changed here. The marker's IDENTITY is unchanged — it
 * is still exactly (root, namespace, session) — so no collision behaviour
 * moves and the cross-repo and cross-session isolation guarantees are the
 * same guarantees. What changes is how many entries land in one directory.
 *
 * Why it had to change. Flat, every marker this tool has ever written on a
 * machine shares ONE directory, for the life of that machine, and nothing
 * removes them (see `markerDir`, which rules against a cleanup sweep and
 * says why). Measured on the development machine, from this project's own
 * test runs alone: 8983 entries. Entry count grew with sessions GLOBALLY. It
 * now grows with sessions PER REPOSITORY, which is the bound that actually
 * matters — a heavy user of one repository is bounded by their own session
 * count rather than by the sum across every repository they have ever opened.
 *
 * The cost is one `mkdirSync` on a path that already did one, on a hot path
 * (every edit, every turn end). It is not a cleanup mechanism and it deletes
 * nothing: deleting files on the hot path of a hook that fires mid-turn is a
 * worse trade than litter, which remains the ruling.
 *
 * Creation failure is swallowed for the same reason `markerDir`'s is: every
 * marker read and write beneath it is already failure-tolerant, so a
 * directory that cannot be created means the caller consistently fails safe
 * (see `writeJSONMarker`, which reports failure rather than pretending).
 */
export function markerPath(root, sessionId, namespace) {
  const base = markerDir();
  if (base === null) return null;
  const dir = ensureOwnDirectory(join(base, rootTag(root)));
  if (dir === null) return null;
  return join(dir, `${namespace}-${sessionId}`);
}

/**
 * Reads and JSON-parses a marker file. Never throws: an absent, unreadable,
 * or malformed marker all resolve to `fallback` — the safe, permissive
 * default — never a reason to crash or to skip the caller's own logic.
 */
export function readJSONMarker(path, fallback) {
  try {
    const parsed = JSON.parse(readFileSync(path, 'utf8'));
    return parsed && typeof parsed === 'object' ? parsed : fallback;
  } catch {
    return fallback;
  }
}

/**
 * Writes a marker file and reports whether it actually landed on disk.
 * Never throws — but, critically, never PRETENDS success either. The
 * marker is the sole thing bounding how many times a caller may block or
 * report per session; a caller that swallows a write failure and proceeds
 * as if the state was recorded loses the bound it exists to provide, which
 * is strictly worse than under-blocking once. Every caller MUST check the
 * return value and fail open (skip the block/report) when it is `false`.
 */
export function writeJSONMarker(path, state) {
  try {
    // Never through a link planted at the marker's own path: O_NOFOLLOW
    // where the platform defines it (POSIX); elsewhere an lstat first.
    if (constants.O_NOFOLLOW === undefined) {
      let st = null;
      try { st = lstatSync(path); } catch { /* absent: fine */ }
      if (st && st.isSymbolicLink()) return false;
      writeFileSync(path, JSON.stringify(state), 'utf8');
    } else {
      writeFileSync(path, JSON.stringify(state), { encoding: 'utf8', flag: constants.O_WRONLY | constants.O_CREAT | constants.O_TRUNC | constants.O_NOFOLLOW });
    }
    return true;
  } catch {
    return false;
  }
}

// --- Running a repository's own command, bounded ---------------------------
//
// Shared by the two process hooks (audit Tier 3, finding 10): lint-touched.mjs
// used `spawnSync` with a `timeout`, which signals only the SHELL and leaves
// the linter running — the orphan verify-touched.mjs had already fixed for
// itself with the runner below. One runner, two callers.

/**
 * Kills the ENTIRE process tree `child` roots, not merely `child` itself.
 * `spawnSync`'s own `timeout` option only ever signals the direct child —
 * with `shell: true` that is the SHELL, not whatever the shell went on to
 * run, so a `tsc`/test-runner process the shell started survives a timeout
 * kill and keeps running, one orphan per turn, forever, measured.
 *
 * POSIX: `detached: true` at spawn time (see runBounded) makes the shell the
 * leader of a NEW process group; `process.kill(-pid, signal)` (a NEGATIVE
 * pid) signals every process in that group, which ordinarily includes
 * anything the shell spawns, since a child inherits its parent's process
 * group unless it explicitly calls `setsid`/`setpgid` itself.
 *
 * win32 has no POSIX process groups; `taskkill /T /F` walks the OS's own
 * process tree (via the same mechanism Task Manager's "End process tree"
 * uses) regardless of how the tree was spawned, which is the standard win32
 * equivalent.
 */
export function killTree(child) {
  if (!child.pid) return;
  try {
    if (process.platform === 'win32') {
      spawnSync('taskkill', ['/pid', String(child.pid), '/T', '/F'], { stdio: 'ignore' });
    } else {
      process.kill(-child.pid, 'SIGKILL');
    }
  } catch {
    // A kill that cannot even be issued (process already gone, permission
    // denied) must never throw — a hook never throws.
  }
}

/**
 * Runs `command` under a shell, bounded by `timeoutMs` and `maxBuffer`,
 * resolving to a result shaped like `spawnSync`'s own (`status`, `signal`,
 * `error`, `stdout`, `stderr`) plus `timedOut`/`overflowed`. A timeout
 * kills the whole tree (see killTree) and waits up to `killGraceMs` for it
 * to go. An overflow does NOT kill (audit Tier 3, finding 12: it used to,
 * so a passing but verbose command was blamed for the cutoff): the first
 * `maxBuffer` characters of each stream are kept, the rest is dropped, the
 * command runs to its own end and `status` is its own. Never throws; a
 * spawn failure resolves with `error` set, exactly like `spawnSync`.
 */
export function runBounded(command, { cwd, env, timeoutMs, maxBuffer, killGraceMs = 5_000 }) {
  return new Promise(resolvePromise => {
    let settled = false;
    let timedOut = false;
    let overflowed = false;
    let killIssued = false;
    let stdout = '';
    let stderr = '';
    let timer;
    let graceTimer = null;

    const finish = result => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      if (graceTimer) clearTimeout(graceTimer);
      resolvePromise(result);
    };

    let child;
    try {
      child = spawn(command, {
        cwd,
        env,
        shell: true,
        stdio: ['ignore', 'pipe', 'pipe'],
        // POSIX only — see killTree's comment. A no-op flag on win32,
        // where taskkill does the real work regardless.
        detached: process.platform !== 'win32',
      });
    } catch (error) {
      finish({ status: null, signal: null, error, stdout: '', stderr: '', timedOut: false, overflowed: false });
      return;
    }

    const issueKill = () => {
      if (killIssued) return;
      killIssued = true;
      killTree(child);
      graceTimer = setTimeout(() => {
        finish({ status: null, signal: 'SIGKILL', error: null, stdout, stderr, timedOut, overflowed });
      }, killGraceMs);
    };

    const append = (current, chunk) => {
      if (current.length >= maxBuffer) { overflowed = true; return current; }
      const room = maxBuffer - current.length;
      if (chunk.length > room) overflowed = true;
      return current + chunk.slice(0, room);
    };

    child.stdout?.on('data', chunk => { stdout = append(stdout, chunk.toString('utf8')); });
    child.stderr?.on('data', chunk => { stderr = append(stderr, chunk.toString('utf8')); });

    timer = setTimeout(() => {
      timedOut = true;
      issueKill();
    }, timeoutMs);

    child.on('error', error => {
      finish({ status: null, signal: null, error, stdout, stderr, timedOut, overflowed });
    });
    child.on('exit', (code, signal) => {
      finish({ status: code, signal, error: null, stdout, stderr, timedOut, overflowed });
    });
  });
}

/**
 * Normalizes away what is expected to differ between otherwise-identical
 * runs of the SAME failure, so a signature computed over the result is
 * stable across repeated runs of an unfixed problem: absolute paths (which
 * embed a machine- or run-specific directory) and elapsed-time figures
 * (which never repeat exactly). Anything this misses falls back on each
 * caller's own cap, never on this function alone being perfect.
 */
function normalizeForSignature(text) {
  return text
    .replace(/[A-Za-z]:[\\/][^\s"']+/g, '<path>') // C:\Users\...\x, C:/a/b
    .replace(/(?<=[\s"'(]|^)\/(?:[^\s"']+\/)+[^\s"']*/g, '<path>') // POSIX-absolute /a/b/c
    .replace(/\b\d+(?:\.\d+)?\s*(?:ms|s|sec|secs|seconds?|m|min|mins|minutes?)\b/gi, '<time>')
    .replace(/\b\d{1,2}:\d{2}(?::\d{2})?(?:\.\d+)?\b/g, '<time>'); // 0:01:23, 12:34.5
}

export function signatureOf(lines) {
  return createHash('sha256').update(normalizeForSignature(lines.join('\n')), 'utf8').digest('hex');
}

/** A self-imposed defence-in-depth bound, independent of (and stricter
 * than) the platform's own documented 8-consecutive-block Stop-hook cap
 * (`CLAUDE_CODE_STOP_HOOK_BLOCK_CAP`, see verify-touched.mjs's header
 * comment) — shared so both hooks' own bounds move together if this value
 * is ever revisited. */
export const MAX_BLOCKS_PER_SESSION = 3;
